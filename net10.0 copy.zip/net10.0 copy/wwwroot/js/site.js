(function () {
    
    var items = document.querySelectorAll('.reveal');
    if (!('IntersectionObserver' in window) || window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
        items.forEach(function (el) { el.classList.add('in'); });
        return;
    }
    var io = new IntersectionObserver(function (entries) {
        entries.forEach(function (e) {
            if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); }
        });
    }, { threshold: 0.12 });
    items.forEach(function (el) { io.observe(el); });
})();

(function () {
    var top = document.querySelector('.top');
    if (!top) return;
    var on = function () { top.classList.toggle('scrolled', window.scrollY > 8); };
    on(); window.addEventListener('scroll', on, { passive: true });
})();

(function () {
    var b = document.getElementById('totop');
    if (!b) return;
    window.addEventListener('scroll', function () { b.classList.toggle('show', window.scrollY > 600); }, { passive: true });
    b.addEventListener('click', function () { window.scrollTo({ top: 0, behavior: 'smooth' }); });
})();
